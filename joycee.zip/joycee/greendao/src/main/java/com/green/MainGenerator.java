package com.green;

import org.greenrobot.greendao.generator.DaoGenerator;
import org.greenrobot.greendao.generator.Entity;
import org.greenrobot.greendao.generator.Schema;

public class MainGenerator {
    public static void main(String[] args)  throws Exception {

        //place where db folder will be created inside the project folder
        Schema schema = new Schema(1,"fivebrains.joyce.db");

        //Entity i.e. Class to be stored in the database // ie table Language
        Entity operator= schema.addEntity("Language");

        operator.addIdProperty(); //It is the primary key for uniquely identifying a row
        operator.addStringProperty("LanguageName").notNull();  //Not null is SQL constrain
        operator.addStringProperty("imagePath");  //Not null is SQL constrain;
        operator.addStringProperty("audioPath");  //Not null is SQL constrain;
        operator.addStringProperty("name").notNull();  //Not null is SQL constrain;

        //  ./app/src/main/java/   ----   com/codekrypt/greendao/db is the full path
        new DaoGenerator().generateAll(schema, "./app/src/main/java");

    }
}
