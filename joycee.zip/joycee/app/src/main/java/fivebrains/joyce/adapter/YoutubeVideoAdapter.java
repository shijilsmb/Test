package fivebrains.joyce.adapter;

/**
 * Created by Created by Sunil on 11-10-2016.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.R;
import fivebrains.joyce.YoutubeActivity;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;
import fivebrains.joyce.util.YouTubeHelper;

import static fivebrains.joyce.util.AddImageAndVoice.context;


public class YoutubeVideoAdapter extends RecyclerView.Adapter implements YouTubeThumbnailView.OnInitializedListener {
    private List<String> itemsList;
    private Context mContext;
    public static final int VIEW_ITEM = 1;
    public static final int VIEW_PROG = 0;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    RecyclerView recyclerView;
    private YouTubeThumbnailLoader youTubeThumbnailLoader;
    String youtubeid;

    public YoutubeVideoAdapter(Context context, List<String> recomendedArrayList, RecyclerView mrecyclerView) {
        this.itemsList = recomendedArrayList;
        this.mContext = context;
        recyclerView = mrecyclerView;


    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.youtube_row, parent, false);

            return new YoutubeVideoAdapter.SingleItemRowHolder(v);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {


        if (holder instanceof YoutubeVideoAdapter.SingleItemRowHolder) {

            System.out.println("=======itemsList=========="+itemsList.get(position));


            YouTubeHelper youtubeHelper=new YouTubeHelper();
             youtubeid=youtubeHelper.extractVideoIdFromUrl(itemsList.get(position));
             System.out.println("=======youtubeid=========="+youtubeid);

            System.out.println("==========="+"http://img.youtube.com/vi/"+youtubeid+"/0.jpg");
            ((SingleItemRowHolder) holder).mThumnail.initialize(YoutubeActivity.API_KEY, this);

           Glide.with(mContext).load("http://img.youtube.com/vi/"+youtubeid+"/mqdefault.jpg").into(((SingleItemRowHolder) holder).mThumnail1);

            // Picasso
/*
            Picasso.with(mContext)
                    .load("http://img.youtube.com/vi/-OKrloDzGpU/mqdefault.jpg")
                    .into(((SingleItemRowHolder) holder).mThumnail);
*/
            //  Merchants merchants = itemsList.get(position);
            //Language language = itemsList.get(position);

           // ((SingleItemRowHolder) holder).mLanguage.setText(Directory.getFileNameWithoutExtension(language.name).toUpperCase());
        }

    }

    @Override
    public int getItemCount() {
        return itemsList == null ? 0 : itemsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return itemsList.get(position) == null ? VIEW_PROG : VIEW_ITEM;
    }

    @Override
    public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader thumbnailLoader) {
        youTubeThumbnailLoader = thumbnailLoader;
        thumbnailLoader.setOnThumbnailLoadedListener(new ThumbnailLoadedListener());

        youTubeThumbnailLoader.setVideo(youtubeid);
    }

    @Override
    public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult) {

    }



      class ThumbnailLoadedListener implements
            YouTubeThumbnailLoader.OnThumbnailLoadedListener {

        @Override
        public void onThumbnailError(YouTubeThumbnailView arg0, YouTubeThumbnailLoader.ErrorReason arg1) {
           /* Toast.makeText(mContext,
                    "ThumbnailLoadedListener.onThumbnailError()",
                    Toast.LENGTH_LONG).show();*/
        }

        @Override
        public void onThumbnailLoaded(YouTubeThumbnailView arg0, String arg1) {
          /*  Toast.makeText(mContext,
                    "ThumbnailLoadedListener.onThumbnailLoaded()",
                    Toast.LENGTH_LONG).show();*/

        }

    }
    public class SingleItemRowHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.youtubethumbnailview)
        protected YouTubeThumbnailView mThumnail;
        @BindView(R.id.thumnail)
        protected ImageView mThumnail1;

        public SingleItemRowHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);

        }

    }


}