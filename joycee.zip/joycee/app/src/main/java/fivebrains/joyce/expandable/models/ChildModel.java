package fivebrains.joyce.expandable.models;

import android.os.Parcel;
import android.os.Parcelable;

public class ChildModel implements Parcelable {

  private int name;
  private boolean isFavorite;

  public ChildModel(int name, boolean isFavorite) {
    this.name = name;
    this.isFavorite = isFavorite;
  }

  protected ChildModel(Parcel in) {
    name = in.readInt();
  }

  public int getName() {
    return name;
  }

  public boolean isFavorite() {
    return isFavorite;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ChildModel)) return false;

    ChildModel artist = (ChildModel) o;

    if (isFavorite() != artist.isFavorite()) return false;
    //return getName() != null ? getName().equals(artist.getName()) : artist.getName() == null;
    return getName() ==artist.getName();

  }

  @Override
  public int hashCode() {
    int result = getName();//getName() != null ? getName().hashCode() : 0;
    result = 31 * result + (isFavorite() ? 1 : 0);
    return result;
  }

  @Override
  public void writeToParcel(Parcel dest, int flags) {
    dest.writeInt(name);
  }

  @Override
  public int describeContents() {
    return 0;
  }

  public static final Creator<ChildModel> CREATOR = new Creator<ChildModel>() {
    @Override
    public ChildModel createFromParcel(Parcel in) {
      return new ChildModel(in);
    }

    @Override
    public ChildModel[] newArray(int size) {
      return new ChildModel[size];
    }
  };
}

