package fivebrains.joyce;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.HelpAdapter;
import fivebrains.joyce.expandable.listeners.GroupExpandCollapseListener;
import fivebrains.joyce.expandable.models.ExpandableGroup;
import fivebrains.joyce.util.LocaleHelper;

import static android.view.animation.Animation.RELATIVE_TO_SELF;
import static fivebrains.joyce.expandable.GenreDataFactory.makeGenres;

public class HelpActivity extends AppCompatActivity {


    public HelpAdapter adapter;

    boolean first = true;


    @BindView(R.id.txt_title)
    TextView txt_title;

    @BindView(R.id.txt_title_text)
    TextView txt_title_text;

    @BindView(R.id.txt_how_do)
    TextView txt_how_do;

    @BindView(R.id.txt_how_do_text)
    TextView txt_how_do_text;

    @BindView(R.id.list_item_genre_arrow)
    ImageView arrow;

    @BindView(R.id.nested)
    NestedScrollView nested;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);


        ButterKnife.bind(this);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //toolbar.setSubtitle("Test Subtitle");
        toolbar.inflateMenu(R.menu.home);

        toolbar.setNavigationIcon(R.drawable.ic_action_back_arrow);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        Drawable drawable = toolbar.getMenu().findItem(R.id.home).getIcon();

        drawable = DrawableCompat.wrap(drawable);
        DrawableCompat.setTint(drawable, ContextCompat.getColor(this,R.color.white));
        toolbar.getMenu().findItem(R.id.home).setIcon(drawable);

        MenuItem item = toolbar.getMenu().findItem(R.id.spinner);
        Spinner spinner = (Spinner) MenuItemCompat.getActionView(item);

        ArrayAdapter<CharSequence> adapt = ArrayAdapter.createFromResource(this,
                R.array.spinner_list_item_array, R.layout.item_spinner2);
        adapt.setDropDownViewResource(R.layout.item_spinner);

        spinner.setAdapter(adapt);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position==0 ){

                    if (!LocaleHelper.english){
                        LocaleHelper.english =true;
                        setUI();
                    }



                }else {

                    if (LocaleHelper.english){
                        LocaleHelper.english =false;
                        setUI();
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if(item.getItemId()==R.id.home)
                {
                    Intent mainIntent = new Intent(HelpActivity.this,HomeActivity.class);
                    startActivity(mainIntent);
                    finish();
                    // do something
                }else{
                    // do something
                }

                return false;
            }
        });



        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        // RecyclerView has some built in animations to it, using the DefaultItemAnimator.
        // Specifically when you call notifyItemChanged() it does a fade animation for the changing
        // of the data in the ViewHolder. If you would like to disable this you can use the following:
        RecyclerView.ItemAnimator animator = recyclerView.getItemAnimator();
        if (animator instanceof DefaultItemAnimator) {
            ((DefaultItemAnimator) animator).setSupportsChangeAnimations(false);
        }

        Context context = LocaleHelper.setLocale(this, "en");
        Resources resources = context.getResources();

        adapter = new HelpAdapter(resources,makeGenres());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

       /* Button clear = (Button) findViewById(R.id.toggle_button);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //adapter.toggleGroup(makeClassicGenre());

                Context context = LocaleHelper.setLocale(ExpandActivity.this, "fr");
                Resources resources = context.getResources();
                adapter.setResources(resources);
                adapter.notifyDataSetChanged();

            }
        });*/
        recyclerView.setNestedScrollingEnabled(false);


        expandGroup(true);

        adapter.setOnGroupExpandCollapseListener(new GroupExpandCollapseListener() {
            @Override
            public void onGroupExpanded(ExpandableGroup group) {
               if (!mExand)animateExpand();
            }

            @Override
            public void onGroupCollapsed(ExpandableGroup group) {

                if (first) {
                    //for (int i = adapter.getGroups().size() - 1; i >= 0; i--) {
                        expandGroup(false);
                   // }
                }else {
                    checkAllGroupCollapsed();
                }

                first = false;

            }


        });

        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                /* Create an Intent that will start the Menu-Activity. */

                nested.smoothScrollTo(0, 0);
                //Toast.makeText(HelpActivity.this,"ttt",Toast.LENGTH_SHORT).show();
            }
        }, 500);

        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandGroup(!mExand);
            }
        });

    }

    boolean mExand = false;

    public void expandGroup(boolean expand) {

        mExand = expand;

        if (expand){
            animateExpand();
        }else {
            animateCollapse();
        }


        for (int i = adapter.getGroups().size() - 1; i >= 0; i--) {

           /// boolean test = adapter.isGroupExpanded(i);

            if (expand && !adapter.isGroupExpanded(i)) {
                adapter.toggleGroup(i);
            } else if (!expand && adapter.isGroupExpanded(i)) {

                adapter.toggleGroup(i);

            }
        }


        for (int i =0;i< adapter.getGroups().size(); i++) {

           // boolean test = adapter.isGroupExpanded(i);

            if (expand && !adapter.isGroupExpanded(i)) {
                adapter.toggleGroup(i);
            } else if (!expand && adapter.isGroupExpanded(i)) {

                adapter.toggleGroup(i);

            }
        }


      /*if (adapter.isGroupExpanded(i)) {
        return;
      }
      adapter.toggleGroup(i);*/
        setUI();
    }

    private void checkAllGroupCollapsed() {
        boolean expanded = false;
        for (int i = adapter.getGroups().size() - 1; i >= 0; i--) {

            if (adapter.isGroupExpanded(i)){
                expanded = true;
            }

        }


        if (!expanded){
            animateCollapse();
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        adapter.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        adapter.onRestoreInstanceState(savedInstanceState);
    }

    private void setUI(){
        Context context = LocaleHelper.setLocale(HelpActivity.this, LocaleHelper.english?"en":"fr");
        Resources resources = context.getResources();
        adapter.setResources(resources);
        adapter.notifyDataSetChanged();

        txt_title.setText(resources.getString(R.string.help_title));
        txt_title_text.setText(resources.getString(R.string.help_title1));
        txt_how_do.setText(resources.getString(R.string.how_to));
        txt_how_do_text.setText(resources.getString(R.string.how_to_text));


    }

    private void animateExpand() {
        mExand = true;
        RotateAnimation rotate =
                new RotateAnimation(360, 180, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(300);
        rotate.setFillAfter(true);
        arrow.setAnimation(rotate);
    }

    private void animateCollapse() {
        mExand = false;
        RotateAnimation rotate =
                new RotateAnimation(180, 360, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(300);
        rotate.setFillAfter(true);
        arrow.setAnimation(rotate);
    }
}
