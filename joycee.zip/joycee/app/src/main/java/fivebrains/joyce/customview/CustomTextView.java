package fivebrains.joyce.customview;

import android.content.Context;
import android.util.AttributeSet;

import fivebrains.joyce.R;

/**
 *Created by Sunil on 2/10/2016.
 */
public class CustomTextView extends android.widget.TextView {

    public CustomTextView(Context context) {
        super(context);
    }

    public CustomTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet);
    }

    public CustomTextView(Context context, AttributeSet attributeSet, int defStyle) {
        super(context, attributeSet, defStyle);
        init(attributeSet);
    }

    public CustomTextView(Context context, AttributeSet attributeSet, int defStyle, int defStyleRes) {
        super(context, attributeSet, defStyle, defStyleRes);
        init(attributeSet);
    }

    /**
     * Init view based on AttributeSet
     *
     * @param attributeSet
     */
    public void init(AttributeSet attributeSet) {
        Font.setCustomFont(this, getContext(), attributeSet, R.styleable.CustomFont, R.styleable.CustomFont_font);
    }
}
