package fivebrains.joyce.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Sunil on 3/23/2017.
 */

public class Language implements Parcelable {

    public String name;
    public String path;

    public Language(String name, String path) {
        this.name = name;
        this.path = path;
    }

    public Language(String name) {
        this.name = name;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.path);
    }

    public Language() {
    }

    protected Language(Parcel in) {
        this.name = in.readString();
        this.path = in.readString();
    }

    public static final Parcelable.Creator<Language> CREATOR = new Parcelable.Creator<Language>() {
        @Override
        public Language createFromParcel(Parcel source) {
            return new Language(source);
        }

        @Override
        public Language[] newArray(int size) {
            return new Language[size];
        }
    };
}
