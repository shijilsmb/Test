package fivebrains.joyce;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.LanguageAdapter;
import fivebrains.joyce.interfaces.RecyclerItemClickListener;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;
import fivebrains.joyce.util.SharedPrefManager;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
    LanguageAdapter languageAdapter;
    ArrayList<Language> list;
    @BindView(R.id.lock)
    ImageView mLock;
    final Context c = this;

    @BindView(R.id.img)
    ImageView img;
    @BindView(R.id.img1)
    ImageView img1;
    @BindView(R.id.img2)
    ImageView img2;
    @BindView(R.id.img3)
    ImageView img3;
    @BindView(R.id.img4)
    ImageView img4;
    @BindView(R.id.background)
    ImageView background;


    @BindView(R.id.ic_bird)
    ImageView bird;
    @BindView(R.id.ic_mogli)
    ImageView mogli;

    SharedPrefManager sherf = new SharedPrefManager();
    @BindView(R.id.toolbar)
    Toolbar mToolbar;

    @BindView(R.id.textview)
    TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ///this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Joyce");

        img.setVisibility(View.GONE);
        img1.setVisibility(View.GONE);
        img2.setVisibility(View.GONE);
        img3.setVisibility(View.GONE);
        img4.setVisibility(View.GONE);
        background.setVisibility(View.GONE);
        bird.setVisibility(View.GONE);
        mogli.setVisibility(View.GONE);
        Glide.with(this).load(R.drawable.ic_j).into(new GlideDrawableImageViewTarget(img));
        Glide.with(this).load(R.drawable.ic_o).into(new GlideDrawableImageViewTarget(img1));
        Glide.with(this).load(R.drawable.ic_y).into(new GlideDrawableImageViewTarget(img2));
        Glide.with(this).load(R.drawable.ic_c).into(new GlideDrawableImageViewTarget(img3));
        Glide.with(this).load(R.drawable.ic_e).into(new GlideDrawableImageViewTarget(img4));
        Glide.with(this).load(R.drawable.ic_background).into(new GlideDrawableImageViewTarget(background));
        Glide.with(this).load(R.drawable.ic_bird).into(new GlideDrawableImageViewTarget(bird));
        Glide.with(this).load(R.drawable.ic_mogli).into(new GlideDrawableImageViewTarget(mogli));

        Resources res = getResources();
        final int newColor = res.getColor(R.color.white);
        mLock.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);


        mLock.setOnClickListener(this);

        mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(HomeActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Intent i = new Intent(HomeActivity.this, FileActivity.class);
                        i.putExtra("name", list.get(position).name);
                        i.putExtra("title", "Language");
                        i.putExtra("tag", "0");
                        startActivity(i);

                    }
                })
        );

        /*mToolbar.inflateMenu(R.menu.main);

        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if(item.getItemId()==R.id.help)
                {
                    Intent mainIntent = new Intent(HomeActivity.this,HelpActivity.class);
                    startActivity(mainIntent);
                    //finish();
                    // do something
                }else if(item.getItemId()==R.id.royalty){
                    Intent mainIntent = new Intent(HomeActivity.this,MainActivity.class);
                    startActivity(mainIntent);
                }else if(item.getItemId()==R.id.parental_code){
                    showParental();
                }

                return false;
            }
        });*/


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if(item.getItemId()==R.id.help)
        {
            Intent mainIntent = new Intent(HomeActivity.this,HelpActivity.class);
            startActivity(mainIntent);
            //finish();
            // do something
            return true;
        }else if(item.getItemId()==R.id.royalty){
            Intent mainIntent = new Intent(HomeActivity.this,MainActivity.class);
            startActivity(mainIntent);
            return true;
        }else if(item.getItemId()==R.id.parental_code){
            showParental();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void onStart() {
        super.onStart();
        list = Directory.readFolder(HomeActivity.this);
        if (list.size()>1) {
            textview.setVisibility(View.VISIBLE);
        }
        else if(list.size() == 0)
        {
            textview.setVisibility(View.VISIBLE);
            textview.setText("No files in your folder");
        }
        else
        {
            textview.setVisibility(View.GONE);
        }
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(HomeActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());
        languageAdapter = new LanguageAdapter(HomeActivity.this, list, mRecyclerview);
        mRecyclerview.setAdapter(languageAdapter);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            /*case R.id.menu:
                showParental();
                break;*/
            case R.id.lock:


              /*  String code = sherf.getParentalCode(this);

                if (code != null) {
                    perentalPopup(code);

                } else {
                    setParentalcode();
                }
*/

                break;
        }
    }

    private void showParental(){
        String code = sherf.getParentalCode(this);

        if (code != null) {
            perentalPopup(code);

        } else {
            setParentalcode();
        }
    }

    private void setParentalcode() {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.set_parental_code, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);

        final EditText userInputDialogEditText = (EditText) mView.findViewById(R.id.password);

        final EditText confirmPassword = (EditText) mView.findViewById(R.id.confirm_password);

        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();


        final Button mok = (Button) mView.findViewById(R.id.ok);
        mok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userInputDialogEditText.getText().toString().equals("")) {


                    Toast.makeText(HomeActivity.this, "Please input 4 digit perental code", Toast.LENGTH_SHORT).show();
/*
                    Intent in = new Intent(HomeActivity.this, LanguageActivity.class);
                    //in.putExtra("title","Teacher");
                    startActivity(in);
                    alertDialogAndroid.dismiss();
*/

                } else if (!userInputDialogEditText.getText().toString().equals(confirmPassword.getText().toString())) {

                    Toast.makeText(HomeActivity.this, "Please Valid perental code", Toast.LENGTH_SHORT).show();

                } else {
                    //Toast.makeText(getApplicationContext(), "Invalid Perent Code", Toast.LENGTH_SHORT).show();

                    sherf.setParentalCode(HomeActivity.this, userInputDialogEditText.getText().toString());
                    Intent in = new Intent(HomeActivity.this, LanguageActivity.class);
                    //in.putExtra("title","Teacher");
                    startActivity(in);
                    alertDialogAndroid.dismiss();
                }
            }
        });

    }


    private void perentalPopup(final String code) {

        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.user_input_dialog, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);

        final EditText userInputDialogEditText = (EditText) mView.findViewById(R.id.password);


        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();


        final Button mok = (Button) mView.findViewById(R.id.ok);
        mok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userInputDialogEditText.getText().toString().equals(code)) {

                    Intent in = new Intent(HomeActivity.this, LanguageActivity.class);
                    //in.putExtra("title","Teacher");
                    startActivity(in);
                    alertDialogAndroid.dismiss();

                } else {


                    Toast.makeText(getApplicationContext(), "Invalid Perent Code", Toast.LENGTH_SHORT).show();
                }


                if (userInputDialogEditText.getText().toString().equals("145698063247853")) {
                    alertDialogAndroid.dismiss();
                    showParentalcode(code);
                }
            }
        });

    }

    private void showParentalcode(String code) {

        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.show_code_dialog, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);

        final TextView show_code = (TextView) mView.findViewById(R.id.showcode);

        show_code.setText(code);

        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();


        final Button mok = (Button) mView.findViewById(R.id.ok);
        mok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent in = new Intent(HomeActivity.this, LanguageActivity.class);
                //in.putExtra("title","Teacher");
                startActivity(in);
                alertDialogAndroid.dismiss();


            }
        });

    }

}
