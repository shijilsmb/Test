package fivebrains.joyce.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.List;

import fivebrains.joyce.db.Language;
import fivebrains.joyce.fragment.PageFragment;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    private List<fivebrains.joyce.models.Language> images;

    public ViewPagerAdapter(FragmentManager fm, List<fivebrains.joyce.models.Language> imagesList) {
        super(fm);
        this.images = imagesList;
    }

    @Override
    public Fragment getItem(int position) {
        return PageFragment.getInstance(images.get(position).name);
    }

    @Override
    public int getCount() {
        return images.size();
    }
}
