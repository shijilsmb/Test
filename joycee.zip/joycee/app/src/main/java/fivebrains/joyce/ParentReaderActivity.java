package fivebrains.joyce;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.ParentAdapter;
import fivebrains.joyce.customview.SimpleDividerItemDecoration;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.AddImageAndVoice;
import fivebrains.joyce.util.Directory;

public class ParentReaderActivity extends AppCompatActivity {
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
    ParentAdapter languageAdapter;
    ArrayList<Language> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_perent_reader);
        ButterKnife.bind(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();

        String mName = intent.getStringExtra("name");
        String path = intent.getStringExtra("path");
        String langName = intent.getStringExtra("langName");


        System.out.println("=======name===" + mName);

        getSupportActionBar().setTitle(Directory.getFileNameWithoutExtension(mName).toUpperCase());


        File file = new File(path);
        System.out.println("=======file===" + file.toString());
        // i have kept text.txt in the sd-card

        if (file.exists())   // check if file exist
        {

            //Read text from file
            StringBuilder text = new StringBuilder();
            try {
                FileInputStream fis = new FileInputStream(file);
                InputStreamReader isr = new InputStreamReader(fis, "UTF-16LE");
                BufferedReader br = new BufferedReader(isr);

                //   BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                String result = "";
                while ((line = br.readLine()) != null) {
                    //text.append(line);
                    if (!line.trim().isEmpty()) {


                        // line.toString().trim();
                        // line = line.replaceAll("\\s+", " ");
                        System.out.println("=======line==========" + line);

                        List<String> animalList = Arrays.asList(line.replaceAll("\\s", "").split("\\|"));

                        System.out.println("=======animalList==========" + animalList);

                        //  List<String> items = Arrays.asList(str.split("\\s*,\\s*"));
                        String[] values = line.split("\\|");
                        for (String str : values) {

                            System.out.println("=======str====" + str.trim());


                            // System.out.println(str);
                            String unicode = Directory.getUnicodeValue(str);
                            // System.out.println("=======unicode=========="+unicode);

                            String charcter = Directory.getNormalString(unicode);
                            list.add(new Language(charcter));
                            System.out.println("======charcter===========" + charcter);
                            //  mText.append(","+charcter);

                        }
                    }

                }


            } catch (IOException e) {
                //You'll need to add proper error handling here
            }
            //Set the text
            // tv.setText(text);
            System.out.println("=======text==========" + text);


        } else {
            // tv.setText("Sorry file doesn't exist!!");
            System.out.println("=======Sorry file doesn't exist!!==========");
        }


        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(ParentReaderActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());


        //Drawable dividerDrawable = ContextCompat.getDrawable(this, R.drawable.vertical_divider);

        //  mRecyclerview.addItemDecoration(new DividerItemDecoration(dividerDrawable));
       /* mRecyclerview.addItemDecoration(
                new DividerItemDecoration(getApplicationContext(), null));*/
       /* DividerItemDecoration verticalDecoration = new DividerItemDecoration(mRecyclerview.getContext(),
                DividerItemDecoration.VERTICAL);
        Drawable verticalDivider = ContextCompat.getDrawable(getApplicationContext(), R.drawable.vertical_divider);
        verticalDecoration.setDrawable(verticalDivider);
        mRecyclerview.addItemDecoration(verticalDecoration);*/

        System.out.println("===ccc==name====="+langName);
        languageAdapter = new ParentAdapter(ParentReaderActivity.this, list,langName, mRecyclerview);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(this));
        mRecyclerview.setAdapter(languageAdapter);
        /*mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(TextFileReaderActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Intent i = new Intent(TextFileReaderActivity.this, TextFileReaderActivity.class);
                        i.putExtra("data", list.get(position).name);
                        startActivity(i);

                    }
                })
        );*/
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case AddImageAndVoice.RequestPermissionCode:
                if (grantResults.length > 0) {

                    boolean StoragePermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean RecordPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (StoragePermission && RecordPermission) {

                        Toast.makeText(ParentReaderActivity.this, "Permission Granted", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(ParentReaderActivity.this,"Permission Denied",Toast.LENGTH_LONG).show();

                    }
                }

                break;
        }
    }



    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){

        AddImageAndVoice.onActivityResult(requestCode, resultCode, data);

/*
        if(requestCode == 1){

            if(resultCode == RESULT_OK){

                //the selected audio.
                Uri uri = data.getData();
                System.out.println("=========uri===="+uri);

            }
        }
*/
        super.onActivityResult(requestCode, resultCode, data);
    }
}
