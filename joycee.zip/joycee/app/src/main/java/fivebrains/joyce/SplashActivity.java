package fivebrains.joyce;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.util.Directory;

public class SplashActivity extends AppCompatActivity {

    /** Duration of wait **/
    private final int SPLASH_DISPLAY_LENGTH = 3000;
    private int STORAGE_PERMISSION_CODE = 23;

    @BindView(R.id.img)ImageView img;
    @BindView(R.id.img1)ImageView img1;
    @BindView(R.id.img2)ImageView img2;
    @BindView(R.id.img3)ImageView img3;
    @BindView(R.id.img4)ImageView img4;
    @BindView(R.id.ic_splash_g)ImageView ic_splash_g;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);
        ButterKnife.bind(this);

        Glide.with(this).load(R.drawable.ic_j).into(new GlideDrawableImageViewTarget(img));
        Glide.with(this).load(R.drawable.ic_o).into(new GlideDrawableImageViewTarget(img1));
        Glide.with(this).load(R.drawable.ic_y).into(new GlideDrawableImageViewTarget(img2));
        Glide.with(this).load(R.drawable.ic_c).into(new GlideDrawableImageViewTarget(img3));
        Glide.with(this).load(R.drawable.ic_e).into(new GlideDrawableImageViewTarget(img4));
        Glide.with(this).load(R.drawable.ic_gif_splash).into(new GlideDrawableImageViewTarget(ic_splash_g));


        if(isReadStorageAllowed()) {
            //If permission is already having then showing the toast
            //Toast.makeText(SplashActivity.this, "You already have the permission", Toast.LENGTH_LONG).show();
            //Existing the method with return
            Directory.createFolder(SplashActivity.this);
            splashRun();
            return;
        }
        //else{
            //If the app has not the permission then asking for the permission
            requestStoragePermission();
       // }




    }

    private void splashRun() {
        /* New Handler to start the Menu-Activity
         * and close this Splash-Screen after some seconds.*/
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                /* Create an Intent that will start the Menu-Activity. */
                Intent mainIntent = new Intent(SplashActivity.this,HomeActivity.class);
                startActivity(mainIntent);
                finish();
            }
        }, SPLASH_DISPLAY_LENGTH);

    }


    //We are calling this method to check the permission status
    private boolean isReadStorageAllowed() {
        //Getting the permission status
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        //If permission is granted returning true
        if (result == PackageManager.PERMISSION_GRANTED)
            return true;

        //If permission is not granted returning false
        return false;
    }

    //Requesting permission
    private void requestStoragePermission(){

        if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.READ_EXTERNAL_STORAGE)){
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }

        //And finally ask for the permission
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION_CODE);
    }



    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if(requestCode == STORAGE_PERMISSION_CODE){

            //If permission is granted
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){

                //Displaying a toast
               // Toast.makeText(this,"Permission granted now you can read the storage",Toast.LENGTH_LONG).show();

                Directory.createFolder(SplashActivity.this);
                splashRun();
            }else{
                //Displaying another toast if permission is not granted
                Toast.makeText(this,"Oops you just denied the permission",Toast.LENGTH_LONG).show();
            }
        }
    }
}
