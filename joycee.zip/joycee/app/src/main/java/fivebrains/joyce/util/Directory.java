package fivebrains.joyce.util;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;

import fivebrains.joyce.models.Language;

import static android.os.Environment.getExternalStorageDirectory;

/**
 * Created by Sunil on 3/23/2017.
 */

public class Directory {

    public static String root="/";
    public static String FOLDER = "Joyce";

    public static void createFolder(Context context) {

        File mediaStorageDir = new File(getExternalStorageDirectory(), FOLDER);

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("App", "failed to create directory");
            }
        } else {
            Log.d("App", "failed to create directory");
            // Toast.makeText(context, "Folder already created",Toast.LENGTH_SHORT).show();
        }

    }


    public static void createLanguageFolder(Context context,String folderName) {

        File folder = new File(Environment.getExternalStorageDirectory() + "/"+FOLDER+"/"+folderName);
        boolean success = false;
        if (!folder.exists()) {
            success = folder.mkdirs();
        }
        if (!success) {
        } else {
        }

    }




    public static ArrayList<Language> readFolder(Context context) {

        String patsh = Environment.getExternalStorageDirectory().toString() + "/" + FOLDER;
        System.out.println("=======patsh==" + patsh);
        File fpath = new File(patsh);
        ArrayList<Language> fileList = new ArrayList<Language>();

        File[] files = fpath.listFiles();
        fileList.clear();

        if (files ==null || files.length==0)return fileList;

        for (File file : files) {
            fileList.add(new Language(file.getName(), file.getPath()));
            System.out.println("=======Name==" + file.getName());
        }

        return fileList;
    }



/*
    public static ArrayList<Language> readFolder(Context context) {

        String patsh = Environment.getExternalStorageDirectory().toString() + "/" + FOLDER;
        System.out.println("=======patsh==" + patsh);
        File fpath = new File(patsh);
        ArrayList<Language> fileList = new ArrayList<Language>();

        File[] files = fpath.listFiles();
        if(!patsh.equals(root)) {
            fileList.add(new Language(root, root));
            //item.add(root);
            //path.add(root);
            fileList.add(new Language("../", fpath.getParent()));
            // item.add("../");
            //path.add(f.getParent());
        }

        fileList.clear();
        for (File file : files) {
            fileList.add(new Language(file.getName(), file.getPath()));
            System.out.println("=======Name==" + file.getName());
        }

        return fileList;
    }
*/



    public static ArrayList<Language> readTextFile(Context context, String path) {

        String patsh = Environment.getExternalStorageDirectory().toString() + "/" + FOLDER + "/" + path;
        System.out.println("======text=file==" + patsh);
        File fpath = new File(patsh);
        ArrayList<Language> fileList = new ArrayList<Language>();

        File[] files = fpath.listFiles();
        fileList.clear();
        for (File file : files) {
            fileList.add(new Language(file.getName(), file.getPath()));
            System.out.println("====read Text file===Name==" + file.getName());
        }

        return fileList;
    }

    public static String getFileNameWithoutExtension(String name) {
        // String name = file.getName();
        int pos = name.lastIndexOf('.');
        if (pos > 0 && pos < (name.length() - 1)) {
            // there is a '.' and it's not the first, or last character.
            return name.substring(0, pos);
        }
        return name;
    }





    public static String getUnicodeValue(String line) {

        String hexCodeWithLeadingZeros = "";
        try {
            for (int index = 0; index < line.length(); index++) {
                String hexCode = Integer.toHexString(line.codePointAt(index)).toUpperCase();
                String hexCodeWithAllLeadingZeros = "0000" + hexCode;
                String temp = hexCodeWithAllLeadingZeros.substring(hexCodeWithAllLeadingZeros.length() - 4);
                hexCodeWithLeadingZeros += ("\\u" + temp);
            }
            return hexCodeWithLeadingZeros;
        } catch (NullPointerException nlpException) {
            return hexCodeWithLeadingZeros;
        }
    }


    public static String getNormalString(String unicodeString) {
        String str = unicodeString.split(" ")[0];
        str = str.replace("\\", "");
        String[] arr = str.split("u");
        String text = "";
        for (int i = 1; i < arr.length; i++) {
            int hexVal = Integer.parseInt(arr[i], 16);
            text += (char) hexVal;
        }
        return text;
    }



    public static void createAudioFolder(Context context) {

        File mediaStorageDir = new File(getExternalStorageDirectory(), "JoyceSound");

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("App", "failed to create directory");
            }
        } else {
            Log.d("App", "failed to createg directory");
            // Toast.makeText(context, "Folder already created",Toast.LENGTH_SHORT).show();
        }

    }
}
