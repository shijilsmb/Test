package fivebrains.joyce;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.CommanAdapter;
import fivebrains.joyce.customview.SimpleDividerItemDecoration;
import fivebrains.joyce.db.DatabaseHandler;
import fivebrains.joyce.interfaces.RecyclerItemClickListener;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;

public class TextFileReaderActivity extends AppCompatActivity {
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
    CommanAdapter languageAdapter;
    ArrayList<Language> list = new ArrayList<>();

  //  @BindView(R.id.img)
   // ImageView mImg;
    @BindView(R.id.back)
    ImageView mBack;
    @BindView(R.id.title_name)
    TextView mName;

    @BindView(R.id.img_puppey)
    ImageView mImg_puppy;
    @BindView(R.id.img_rabbit)
    ImageView mImg_rabbit;
    private MediaPlayer mediaPlayer;
    public static String langName;
    private RecyclerView.LayoutManager mLayoutManager;
    public int flag = 0;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_text_file_reader);
        ButterKnife.bind(this);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        //  Glide.with(this).load(R.drawable.ic_bats).into(new GlideDrawableImageViewTarget(mImg));

        /*Glide.with(this).load(R.drawable.ic_puppey).into(new GlideDrawableImageViewTarget(mImg_puppy));*/

        Glide.with(this).load(R.drawable.ic_rabbit).into(new GlideDrawableImageViewTarget(mImg_rabbit));

        Glide.with(this).load(R.drawable.ic_puppey).placeholder(R.drawable.ic_puppey)
                .into(new GlideDrawableImageViewTarget(mImg_puppy));

        Resources res = getResources();
        final int newColor = res.getColor(R.color.gray);
        mBack.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

       /* mImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (flag == 0) {
                    flag = 1; // 1 => Button ON
                    mLayoutManager = new GridLayoutManager(TextFileReaderActivity.this, 2);
                    mRecyclerview.setLayoutManager(mLayoutManager);
                }
                else{
                    flag = 0; // 0 => Button OFF
                    mLayoutManager = new LinearLayoutManager(TextFileReaderActivity.this);
                    mRecyclerview.setLayoutManager(mLayoutManager);
                }
            }
        });*/

        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        // setSupportActionBar(toolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        final String path = intent.getStringExtra("path");

        langName = intent.getStringExtra("langName");

       List<fivebrains.joyce.db.Language> mlist=  DatabaseHandler.getAllRecord(this,langName);

      for (int i=0;i<mlist.size();i++){
          System.out.println("====get audio=======" + mlist.get(i).getAudioPath());
          System.out.println("====get image=======" + mlist.get(i).getImagePath());
          System.out.println("=====get name======" + mlist.get(i).getName());
          System.out.println("====get language=======" + mlist.get(i).getLanguageName());
      }
      //  System.out.println("=======name===" + name);
     //   mName.setText(Directory.getFileNameWithoutExtension(name).toUpperCase());
        getSupportActionBar().setTitle(Directory.getFileNameWithoutExtension(name).toUpperCase());
        // getSupportActionBar().setTitle(Directory.getFileNameWithoutExtension(name).toUpperCase());

        File file = new File(path);
        System.out.println("=======file===" + file.toString());
        // i have kept text.txt in the sd-card

        if (file.exists())   // check if file exist
        {
            //Read text from file
            StringBuilder text = new StringBuilder();
            try {
                FileInputStream fis = new FileInputStream(file);
                InputStreamReader isr = new InputStreamReader(fis, "UTF-16LE");
                BufferedReader br = new BufferedReader(isr);

                //   BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                String result = "";
                while ((line = br.readLine()) != null) {
                    //text.append(line);
                    if (!line.trim().isEmpty()) {


                        // line.toString().trim();
                        // line = line.replaceAll("\\s+", " ");
                       // System.out.println("=======line==========" + line);

                        List<String> animalList = Arrays.asList(line.replaceAll("\\s", "").split("\\|"));

                       // System.out.println("=======animalList==========" + animalList);

                        //  List<String> items = Arrays.asList(str.split("\\s*,\\s*"));
                        String[] values = line.split("\\|");
                        for (String str : values) {

                            System.out.println("=======str====" + str.trim());


                            // System.out.println(str);
                            String unicode = Directory.getUnicodeValue(str);
                            // System.out.println("=======unicode=========="+unicode);

                            String charcter = Directory.getNormalString(unicode);
                            list.add(new Language(charcter));
                          //  System.out.println("======charcter===========" + charcter);
                            //  mText.append(","+charcter);

                        }
                    }

                }


            } catch (IOException e) {
                //You'll need to add proper error handling here
            }
            //Set the text
            // tv.setText(text);
            System.out.println("=======text==========" + text);


        } else {
            // tv.setText("Sorry file doesn't exist!!");
            System.out.println("=======Sorry file doesn't exist!!==========");
        }


        mLayoutManager = new LinearLayoutManager(TextFileReaderActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());
        languageAdapter = new CommanAdapter(TextFileReaderActivity.this, list, mRecyclerview);
        mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(this));
        mRecyclerview.setAdapter(languageAdapter);
        mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(TextFileReaderActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {

                        // Toast.makeText(TextFileReaderActivity.this, "hello", Toast.LENGTH_SHORT).show();

                        final String[] values = list.get(position).name.split("\\*");

                        final List<fivebrains.joyce.db.Language> lang = DatabaseHandler.getRecord(TextFileReaderActivity.this, values[0]);
                        if (null == lang || lang.isEmpty()) {

                        } else {
                            String path = lang.get(0).getAudioPath();
                            System.out.println("======AudioSavePathInDevice==data base=====" + path);
                            if (path != null) {
                                mediaPlayer = new MediaPlayer();
                                try {
                                    mediaPlayer.setDataSource(path);
                                    mediaPlayer.prepare();
                                   // showMessage(values[0]);
                                } catch (IOException e) {
                                    e.printStackTrace();

                                }

                                mediaPlayer.start();
                                //Toast.makeText(c, "Recording Playing", Toast.LENGTH_LONG).show();
                            }
                        }

                        /*if(path!=null) {

                        }*/
/*
                        Intent i = new Intent(TextFileReaderActivity.this, TextFileReaderActivity.class);
                        i.putExtra("data", list.get(position).name);
                        startActivity(i);
*/

                    }
                })
        );
    }

    private void showMessage(String name) {
        LayoutInflater inflater = getLayoutInflater();

        View toastLayout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.toast_root_view));

        TextView header = (TextView) toastLayout.findViewById(R.id.toast_header);
        // header.setText("Message for you:");

        TextView body = (TextView) toastLayout.findViewById(R.id.toast_body);
        body.setText(name);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastLayout);
        toast.show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
