package fivebrains.joyce;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.util.LocaleHelper;

public class MainActivity extends AppCompatActivity {


    @BindView(R.id.txt_title)
    TextView txt_title;

    @BindView(R.id.txt_message)
    TextView txt_message;

    @BindView(R.id.txt_next)
    TextView txt_next;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //toolbar.setSubtitle("Test Subtitle");
        toolbar.inflateMenu(R.menu.home);




        Drawable drawable = toolbar.getMenu().findItem(R.id.home).getIcon();

        drawable = DrawableCompat.wrap(drawable);
        DrawableCompat.setTint(drawable, ContextCompat.getColor(this,R.color.colorPrimary));
        toolbar.getMenu().findItem(R.id.home).setIcon(drawable);

        MenuItem item = toolbar.getMenu().findItem(R.id.spinner);
        Spinner spinner = (Spinner) MenuItemCompat.getActionView(item);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_list_item_array, R.layout.item_spinner1);
        adapter.setDropDownViewResource(R.layout.item_spinner);

        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position==0 ){

                    if (!LocaleHelper.english){
                        LocaleHelper.english =true;
                        setUI();
                    }



                }else {

                    if (LocaleHelper.english){
                        LocaleHelper.english =false;
                        setUI();
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if(item.getItemId()==R.id.home)
                {
                    Intent mainIntent = new Intent(MainActivity.this,HomeActivity.class);
                    startActivity(mainIntent);
                    //finish();
                    // do something
                }else{
                    // do something
                }

                return false;
            }
        });

        txt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(MainActivity.this,HelpActivity.class);
                startActivity(mainIntent);
                //finish();
            }
        });

        findViewById(R.id.ic_back) .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        setUI();
    }

    private void setUI(){
        Context context = LocaleHelper.setLocale(MainActivity.this, LocaleHelper.english?"en":"fr");
        Resources resources = context.getResources();
        //adapter.setResources(resources);
        //adapter.notifyDataSetChanged();

        txt_title.setText(resources.getString(R.string.royalty_title));
        txt_message.setText(resources.getString(R.string.royalty_content));
        txt_next.setText(resources.getString(R.string.next));


    }
}
