package fivebrains.joyce;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.FileAdapter;
import fivebrains.joyce.adapter.YoutubeVideoAdapter;
import fivebrains.joyce.interfaces.RecyclerItemClickListener;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;
import fivebrains.joyce.util.FileOpen;

public class YoutubeActivity extends AppCompatActivity {
     @BindView(R.id.toolbar)Toolbar toolbar;
    List<String> list = new ArrayList<>();
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
   // @BindView(R.id.img)
    //ImageView mImg;

    @BindView(R.id.img_puppey)
    ImageView mImg_puppy;
    @BindView(R.id.img_rabbit)
    ImageView mImg_rabbit;
    private MediaPlayer mediaPlayer;
    public static String langName;
    private RecyclerView.LayoutManager mLayoutManager;
    public static final String API_KEY = "AIzaSyCe6tORd9Ch4lx-9Ku5SQ476uS9OtZYsWA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);
        ButterKnife.bind(this);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Videos");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        final String path = intent.getStringExtra("path");

       youtubeLink(path);
        mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(YoutubeActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Intent i = new Intent(YoutubeActivity.this, YoutubePlayerActivity.class);
                        i.putExtra("url", list.get(position));
                        startActivity(i);
                    }

                })
        );


    }

    private void youtubeLink(String path) {
        File file = new File(path);
        System.out.println("=======file===" + file.toString());
        // i have kept text.txt in the sd-card

        if (file.exists())   // check if file exist
        {
            //Read text from file
            StringBuilder text = new StringBuilder();
            try {
                FileInputStream fis = new FileInputStream(file);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);

                //   BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                String result = "";
                while ((line = br.readLine()) != null) {
                    //text.append(line);
                    if (!line.trim().isEmpty()) {


                        //  System.out.println("=======line====" + line);

                       // list= Arrays.asList(line.replaceAll("\\s", "").split(","));
                       // System.out.println("=======list====" + list);
                        String[] values = line.split(",");
                        for (String str : values) {

                            list.add(str);
                            //  System.out.println("======charcter===========" + charcter);
                            //  mText.append(","+charcter);

                        }

                    }
                }


            } catch (IOException e) {
                //You'll need to add proper error handling here
            }
            //Set the text
            // tv.setText(text);
            System.out.println("=======text==========" + list.size());


        } else {
            // tv.setText("Sorry file doesn't exist!!");
            System.out.println("=======Sorry file doesn't exist!!==========");
        }


        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(YoutubeActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());

        YoutubeVideoAdapter languageAdapter = new YoutubeVideoAdapter(YoutubeActivity.this, list, mRecyclerview);
        mRecyclerview.setAdapter(languageAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
