package fivebrains.joyce.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import org.greenrobot.greendao.query.DeleteQuery;
import org.greenrobot.greendao.query.Query;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

/**
 * Created by Sunil on 3/30/2017.
 */

public class DatabaseHandler {
    //Dao --> Data Access Object
    public static LanguageDao languagedao; // Sql access object
    public static Language temp_log_object; // Used for creating a LOG Object

    String log_text = "";  //Entered text data is save in this variable
    public static final String DB_NAME = "lang-db";  //Name of Db file in the Device


    public static LanguageDao setupDb(Context context) {
        DaoMaster.DevOpenHelper masterHelper = new DaoMaster.DevOpenHelper(context, DB_NAME, null); //create database db file if not exist
        SQLiteDatabase db = masterHelper.getWritableDatabase();  //get the created database db file
        DaoMaster master = new DaoMaster(db);//create masterDao
        DaoSession masterSession = master.newSession(); //Creates Sess

        return masterSession.getLanguageDao();
    }


    //---------------------------------SQL QUERY Functions-----------------------------------------//
    public static String getFromSQL() {
        List<Language> log_list = languagedao.queryBuilder().orderDesc(LanguageDao.Properties.Id).build().list();
        //Get the list of all LOGS in Database in descending order

        if (log_list.size() > 0) {  //if list is not null

            return log_list.get(0).getName();
            //get(0)--> 1st object
            // getText() is the function in LOG class
        }
        return "";
    }


    public static void update(Context c, String name, String audiopath) {

        languagedao = setupDb(c);
        System.out.println("====update audio=name============" + name);
        System.out.println("====update=audio imagepath============" + audiopath);

        final List<Language> wines = languagedao.queryBuilder().where(LanguageDao.Properties.Name.eq(name)).list();
        for (Language language : wines) {
            language.setAudioPath(audiopath);
            languagedao.update(language);
        }

    }


    public static void updateImagePath(Context c, String name, String imagepath) {
        languagedao = setupDb(c);

        // languagedao.queryBuilder().where(LanguageDao.Properties.Name.eq(name)).list();
        //languagedao.update(name);

        System.out.println("====update=name============" + name);
        System.out.println("====update=imagepath============" + imagepath);
        final List<Language> wines = languagedao.queryBuilder().where(LanguageDao.Properties.Name.eq(name)).list();
        // wines.get(0).setImagePath(imagepath);
        // Language lang=new Language();
        //lang.setImagePath(imagepath);
        // languagedao.update(lang);
        for (Language language : wines) {
            language.setImagePath(imagepath);
            languagedao.update(language);
        }

    }

    public static List<Language> getRecord(Context c, String name) {
        languagedao = setupDb(c);
        List<Language> lang = null;
        if (languagedao != null) {
            lang = languagedao.queryBuilder()
                    .where(LanguageDao.Properties.Name.eq(name))
                    .list();

            if (null == lang || lang.isEmpty()) {

            } else {
                System.out.println("====get audio=======" + lang.get(0).getAudioPath());
                System.out.println("====get image=======" + lang.get(0).getImagePath());
                System.out.println("=====get name======" + lang.get(0).getName());
                System.out.println("====get language=======" + lang.get(0).getLanguageName());
            }

        }
        return lang;
    }

    public static void SaveToSQL(Context c, Language log_object) {
        languagedao = setupDb(c);
        System.out.println("==save===audio======" + log_object.getAudioPath());
        System.out.println("===save===image=====" + log_object.getImagePath());
        System.out.println("===save Name========" + log_object.getName());
        System.out.println("===save Language nam========" + log_object.getLanguageName());
        languagedao.insert(log_object);
    }


    public static List<Language> getAllRecord(Context c, String name) {
        languagedao = setupDb(c);
        List<Language> lang = null;
        if (languagedao != null) {
            lang = languagedao.queryBuilder()
                    .where(LanguageDao.Properties.LanguageName.eq(name))
                    .list();

            if (null == lang || lang.isEmpty()) {

            } else {
/*                System.out.println("====get audio=======" + lang.get(0).getAudioPath());
                System.out.println("====get image=======" + lang.get(0).getImagePath());
                System.out.println("=====get name======" + lang.get(0).getName());
                System.out.println("====get language=======" + lang.get(0).getLanguageName());*/
            }

        }
        return lang;
    }

   /* public static void Delete(Context c, String name) {
        languagedao = setupDb(c);

        List<Language> lang = null;
        if (languagedao != null) {

            QueryBuilder<Language> builder = languagedao.queryBuilder().where(LanguageDao.Properties.Name.eq(name));
            Query<Language> query = builder.build();
            DeleteQuery<Language> deleteQuery = builder.buildDelete();
        }


    }*/

    public boolean delete(Context c,String name) {
        languagedao = setupDb(c);
        if (languagedao != null) {
            DeleteQuery<Language> comDeleteQuery = languagedao
                    .queryBuilder()
                    .where(LanguageDao.Properties.Name.eq(name))
                    .buildDelete();
            comDeleteQuery.executeDeleteWithoutDetachingEntities();
            return true;
        }
        return false;
    }
}
