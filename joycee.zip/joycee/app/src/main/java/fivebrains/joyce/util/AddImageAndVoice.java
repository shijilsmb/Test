package fivebrains.joyce.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Random;

import fivebrains.joyce.R;
import fivebrains.joyce.db.DatabaseHandler;
import fivebrains.joyce.db.Language;
import fivebrains.joyce.imagepicker.PickerBuilder;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.app.Activity.RESULT_OK;

/**
 * Created by Sunil on 3/28/2017.
 */

public class AddImageAndVoice {
    static String AudioSavePathInDevice = null;
    static MediaRecorder mediaRecorder;
    static Random random = new Random();
    static String RandomAudioFileName = "ABCDEFGHIJKLMNOP";
    public static final int RequestPermissionCode = 1;
    static MediaPlayer mediaPlayer;

    public static String img;
    public static int flag = 0;
    public static int flag1 = 0;
    public static Context context;
    public  static String fileName;
    public  static String path;
    public  static String langn;
    public static void AddImage(final Context c, final String name, final String langName) {


        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.poup_image_add_popup, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);
        final ImageView mImageview = (ImageView) mView.findViewById(R.id.show_img);


        final List<Language> lang = DatabaseHandler.getRecord(c, name);
        if (null == lang || lang.isEmpty()) {

        } else {
            try {
                if(lang.get(0).getImagePath().equals("")){
                    mImageview.setImageResource(R.mipmap.ic_gallary);
                }
                else{
                    mImageview.setImageURI(Uri.parse(lang.get(0).getImagePath()));
                }


            } catch (Exception e) {
                e.printStackTrace();

            }
        }


        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();
        alertDialogAndroid.setCanceledOnTouchOutside(true);

        /*final Button mSave = (Button) mView.findViewById(R.id.save_image);
        mSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //DatabaseHandler.setupDb(c);
               // long a=1;
                Language language=new Language();
              //  language.setId(a);
                language.setLanguageName(langName);
                language.setImagePath(img);
                language.setAudioPath("hhj");
                language.setName(name);

                System.out.println("==langname="+langName);
                System.out.println("==imageUri.toString()="+img);
                System.out.println("==name="+name);

                DatabaseHandler.SaveToSQL(c,language);
            }
        });*/

        final Button mok = (Button) mView.findViewById(R.id.change_image);
        mok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new PickerBuilder((Activity) c, PickerBuilder.SELECT_FROM_GALLERY)
                        .setOnImageReceivedListener(new PickerBuilder.onImageReceivedListener() {
                            @Override
                            public void onImageReceived(Uri imageUri) {
                                // Toast.makeText(c, "Got image - " + imageUri, Toast.LENGTH_LONG).show();
                                img = imageUri.toString();
                                Language language = new Language();
                                //  language.setId(a);
                                language.setLanguageName(langName);
                                language.setImagePath(img);
                                language.setName(name);
                                System.out.println("==langname=" + langName);
                                // System.out.println("==imageUri.toString()="+img);
                                System.out.println("==name=" + name);

                                if (null == lang || lang.isEmpty()) {
                                    DatabaseHandler.SaveToSQL(c, language);
                                    System.out.println("==not exits=");
                                } else {
                                    DatabaseHandler.updateImagePath(c, name, img);
                                    System.out.println("== exits=");

                                }


                                System.out.println("==imageUri.toString()=" + img);
                                mImageview.setImageDrawable(null);
                                mImageview.setImageURI(Uri.parse(img));


                            }
                        })
                        .setImageName(name)
                        .setImageFolderName("JoyceImg")
                        .withTimeStamp(false)
                        .setCropScreenColor(Color.BLUE)
                        .start();


            }


        });

        final Button buttonRemove = (Button) mView.findViewById(R.id.remove);
        buttonRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                System.out.println("==============delete====");
                if (lang!=null && !lang.isEmpty()) {
                    DatabaseHandler.updateImagePath(c, name, "");
                    alertDialogAndroid.dismiss();
                   // System.out.println("==============delete1===="+lang.get(0).getImagePath());
                   // String myFile = "/JoiceImg/a.jpg";

                   // String my_Path = Environment.getExternalStorageDirectory()+myFile;

                   // System.out.println("==============my_Path===="+my_Path);

                  //  File file = new File(my_Path);
                  //  boolean deleted = file.delete();
                    {
                        try {


                            File fdelete = new File(lang.get(0).getImagePath());
                            if (fdelete.exists()) {
                                if (fdelete.delete()) {

                                    System.out.println("file Deleted :" + lang.get(0).getImagePath());
                                } else {
                                    System.out.println("file not Deleted :" + lang.get(0).getImagePath());
                                }
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                    }
                }

            }
        });
    }


    public static void AddVoice(final Context c, final String name, final String langName) {
        context=c;
        System.out.println("=========filename=====" + name);
        fileName=name;
        langn=langName;
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.poup_add_voice, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);

        final TextView mName = (TextView) mView.findViewById(R.id.voice_text);
        mName.setText("Voice of " + name);

        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();
        alertDialogAndroid.setCanceledOnTouchOutside(true);

        final ImageView mPlaySound = (ImageView) mView.findViewById(R.id.play_sound);

        final ImageView record_sound = (ImageView) mView.findViewById(R.id.record_sound);
        final ImageView gallerySave = (ImageView) mView.findViewById(R.id.gallary);
        gallerySave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_upload = new Intent();
                intent_upload.setType("audio/*");
                intent_upload.setAction(Intent.ACTION_GET_CONTENT);
               // c.startActivityForResult(intent_upload,1);
                ((Activity) c).startActivityForResult(intent_upload,1);
            }
        });


        final TextView mSave = (TextView) mView.findViewById(R.id.save);
        mSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final List<Language> lang = DatabaseHandler.getRecord(c, name);
                if (lang!=null && !lang.isEmpty()) {
                    DatabaseHandler.update(c, name, "");
                    alertDialogAndroid.dismiss();
                    System.out.println("== sound exits=");
                }
            }
        });


        mPlaySound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer = new MediaPlayer();
                if (flag1 == 0) {
                    flag1 = 1; // 1 => Button Pause
                    mPlaySound.setImageResource(R.mipmap.ic_pause);
                    final List<Language> lang = DatabaseHandler.getRecord(c, name);
                    if (null == lang || lang.isEmpty()) {

                    } else {
                         path = lang.get(0).getAudioPath();
                        System.out.println("======AudioSavePathInDevice==data base=====" + path);
                        if (path != null&&!path.equals("")) {
                            try {
                                mediaPlayer.setDataSource(path);
                                mediaPlayer.prepare();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            mediaPlayer.start();
                            Toast.makeText(c, "Sound Playing", Toast.LENGTH_LONG).show();
                        } else {

                            if (path != null) {
                                //mediaPlayer = new MediaPlayer();
                                try {
                                    mediaPlayer.setDataSource(path);
                                    mediaPlayer.prepare();
                                    mediaPlayer.pause();
                                    mediaPlayer.stop();
                                    mediaPlayer.reset();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                mediaPlayer.start();
                                Toast.makeText(c, "Sound Playing", Toast.LENGTH_LONG).show();

                            }
                        }
                    }

                } else {
                    Toast.makeText(c, "Sound Stop", Toast.LENGTH_LONG).show();
                    flag1 = 0; // 0 => Button Play
                    mPlaySound.setImageResource(R.mipmap.ic_play);
                    try {
                        if (path != null) {
                       // mediaPlayer = new MediaPlayer();
                        mediaPlayer.setDataSource(path);
                        mediaPlayer.prepare();
                        mediaPlayer.stop();
                     //   mediaPlayer.release();
                    } }catch (IllegalStateException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }


            }
        });


        record_sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (checkPermission(c)) {
                    if (flag == 0) {
                        flag = 1; // 1 => Button ON
                        record_sound.setImageResource(R.mipmap.ic_stop);
                        Directory.createAudioFolder(c);
                        AudioSavePathInDevice = Environment.getExternalStorageDirectory().toString() + "/" + "JoyceSound" + "/" + name + ".3gp";
                        System.out.println("====AudioSavePathInDevice=======" + AudioSavePathInDevice);
                        MediaRecorderReady();

                        try {
                            mediaRecorder.prepare();

                            mediaRecorder.start();
                        } catch (IllegalStateException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        Toast.makeText(c, "Recording started", Toast.LENGTH_LONG).show();

                    } else {
                        flag = 0; // 0 => Button OFF
                        record_sound.setImageResource(R.mipmap.ic_record_voice);
                        //buttonState.setText("State : OFF");
                        try {
                            if (mediaRecorder != null)
                                mediaRecorder.stop();
                        } catch (IllegalStateException e) {
                            e.printStackTrace();
                        }

                        Toast.makeText(c, "Recording Stop", Toast.LENGTH_LONG).show();

                        System.out.println("==langname=" + langName);
                        System.out.println("==audio" + AudioSavePathInDevice);
                        System.out.println("==name=" + name);
                        Language language = new Language();
                        language.setLanguageName(langName);
                        language.setAudioPath(AudioSavePathInDevice);
                        language.setName(name);

                        //  if(null==lang|| lang.isEmpty()){
                        final List<Language> lang = DatabaseHandler.getRecord(c, name);
                        if (null == lang || lang.isEmpty()) {
                            DatabaseHandler.SaveToSQL(c, language);
                            System.out.println("======SAve path====");

                        } else {

                            String audioPath = lang.get(0).getAudioPath();
                            System.out.println("======audio path===="+audioPath);
                          //  if (!audioPath.equals("")&&audioPath != null) {
                                if(!TextUtils.isEmpty(audioPath)){
                                System.out.println("=sound already saved=");
                            } else {
                                DatabaseHandler.update(c, name, AudioSavePathInDevice);
                                AudioSavePathInDevice=null;
                                System.out.println("== sound exits=");
                            }

                        }

                    }

                } else {

                    requestPermission(c);

                }
            }
        });


    }


    public static boolean checkPermission(Context c) {

        int result = ContextCompat.checkSelfPermission(c, WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(c, RECORD_AUDIO);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }


    public static void MediaRecorderReady() {

        mediaRecorder = new MediaRecorder();

        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);

        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);

        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
       // mediaRecorder.setAudioEncoder(MediaRecorder.getAudioSourceMax());
        //mediaRecorder.setAudioEncodingBitRate(16);
       // mediaRecorder.setAudioSamplingRate(44100);
        mediaRecorder.setOutputFile(AudioSavePathInDevice);

/*
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setAudioEncoder(MediaRecorder.getAudioSourceMax());
        recorder.setAudioEncodingBitRate(16);
        recorder.setAudioSamplingRate(44100);
        recorder.setOutputFile(path);
        recorder.prepare();
        recorder.start();
*/

    }

    public static String CreateRandomAudioFileName(int string) {

        StringBuilder stringBuilder = new StringBuilder(string);

        int i = 0;
        while (i < string) {

            stringBuilder.append(RandomAudioFileName.charAt(random.nextInt(RandomAudioFileName.length())));

            i++;
        }
        return stringBuilder.toString();

    }

    private static void requestPermission(Context c) {

        ActivityCompat.requestPermissions((Activity) c, new String[]{WRITE_EXTERNAL_STORAGE, RECORD_AUDIO}, RequestPermissionCode);

    }

    public static void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("MyAdapter", "onActivityResult");
        if(requestCode == 1){

            if(resultCode == RESULT_OK){

                //the selected audio.
                Uri uri = data.getData();
                System.out.println("=======d==uri===="+uri);

                try {
                    String path=PathUtil.getPath(context,uri);
                    Language language = new Language();
                    language.setLanguageName(langn);
                    language.setAudioPath(AudioSavePathInDevice);
                    language.setName(fileName);
                    //  if(null==lang|| lang.isEmpty()){
                    final List<Language> lang = DatabaseHandler.getRecord(context, fileName);
                    if (null == lang || lang.isEmpty()) {
                        DatabaseHandler.SaveToSQL(context, language);
                        System.out.println("======SAve path====");

                    } else {

                        String audioPath = lang.get(0).getAudioPath();
                        System.out.println("======audio path===="+audioPath);
                        //  if (!audioPath.equals("")&&audioPath != null) {
                        if(!TextUtils.isEmpty(audioPath)){
                            System.out.println("=sound already saved=");
                        } else {
                            DatabaseHandler.update(context, fileName, path);
                            System.out.println("== sound exits=");
                        }

                    }

                    System.out.println("=======d==uri===="+path);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

/*
                String path = null;
                if (Build.VERSION.SDK_INT < 11)
                    path = RealPathUtils.getRealPathFromURI_BelowAPI11(context, uri);

                    // SDK >= 11 && SDK < 19
                else if (Build.VERSION.SDK_INT < 19)
                    path = RealPathUtils.getRealPathFromURI_API11to18(context, uri);

                    // SDK > 19 (Android 4.4)
                else
                    path = RealPathUtils.getRealPathFromURI_API19(context, uri);
                Log.d("path", "File Path: " + path);
                // Get the file instance
                File file = new File(path);
*/

            }
        }

    }





}
