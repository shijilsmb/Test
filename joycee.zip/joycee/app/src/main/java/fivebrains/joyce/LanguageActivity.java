package fivebrains.joyce;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.TeacherLanguageAdapter;
import fivebrains.joyce.interfaces.RecyclerItemClickListener;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;

public class LanguageActivity extends AppCompatActivity implements View.OnClickListener {
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
    TeacherLanguageAdapter languageAdapter;
    ArrayList<Language> list;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.fab)
    FloatingActionButton mFavBtn;
    final Context c = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_language);
        ButterKnife.bind(this);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("LANGUAGES");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        mFavBtn.setOnClickListener(this);


        list = Directory.readFolder(LanguageActivity.this);

        // System.out.println("=======list===" + list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(LanguageActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());
        languageAdapter = new TeacherLanguageAdapter(LanguageActivity.this, list, mRecyclerview);
        //  mRecyclerview.addItemDecoration(new SimpleDividerItemDecoration(this));
        mRecyclerview.setAdapter(languageAdapter);

        mRecyclerview.setAdapter(languageAdapter);
        mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(LanguageActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Intent i = new Intent(LanguageActivity.this, LanguageFileActivity.class);
                        i.putExtra("name", list.get(position).name);
                        i.putExtra("title", "Language");
                        i.putExtra("tag", "1");
                        startActivity(i);

                    }
                })
        );
    }


    @Override
    public void onClick(View view) {
        addLanguage();
    }


    private void addLanguage() {

        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
        View mView = layoutInflaterAndroid.inflate(R.layout.popup_language, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
        alertDialogBuilderUserInput.setView(mView);

        final EditText userInputDialogEditText = (EditText) mView.findViewById(R.id.add_lang);


        final AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();

        final Button mok = (Button) mView.findViewById(R.id.add);
        mok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userInputDialogEditText.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please add language", Toast.LENGTH_SHORT).show();

                } else {
                    alertDialogAndroid.dismiss();
                    Directory.createLanguageFolder(LanguageActivity.this, userInputDialogEditText.getText().toString());
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
