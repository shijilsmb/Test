package fivebrains.joyce.expandable;

import java.util.Arrays;
import java.util.List;

import fivebrains.joyce.R;
import fivebrains.joyce.expandable.models.ChildModel;
import fivebrains.joyce.expandable.models.HeadModel;

public class GenreDataFactory {

  public static List<HeadModel> makeGenres() {
    return Arrays.asList(makeFolder(),
            makeContent(),
            makeinsert_video(),
            makecopy_joyce(),
            makecreate_parental(),
            makerecord(),
            makeinsert_picture(),
            makeyoung_ones());
  }



  private static HeadModel makeFolder() {
    return new HeadModel(R.string.create_folder, makeFolderChild(), R.drawable.ic_folder_24px);
  }
  private static List<ChildModel> makeFolderChild() {
    ChildModel queen = new ChildModel(R.string.create_folder_text, true);

    return Arrays.asList(queen);
  }

  private static HeadModel makeContent() {
    return new HeadModel(R.string.create_content, makeContentChild(), R.drawable.ic_view_compact_24px);
  }
  private static List<ChildModel> makeContentChild() {
    ChildModel queen = new ChildModel(R.string.create_content_text, true);
    return Arrays.asList(queen);
  }


  private static HeadModel makeinsert_video() {
    return new HeadModel(R.string.insert_video_link, makeinsert_videoChild(), R.drawable.ic_movie_creation_24px);
  }
  private static List<ChildModel> makeinsert_videoChild() {
    ChildModel queen = new ChildModel(R.string.insert_video_link_text, true);
    return Arrays.asList(queen);
  }

  private static HeadModel makecopy_joyce() {
    return new HeadModel(R.string.copy_joyce_file, makecopy_joyceChild(), R.drawable.ic_copy_joyce);
  }
  private static List<ChildModel> makecopy_joyceChild() {
    ChildModel queen = new ChildModel(R.string.copy_joyce_file_text, true);
    return Arrays.asList(queen);
  }

  private static HeadModel makecreate_parental() {
    return new HeadModel(R.string.create_parental_code, makecreate_parentalChild(), R.drawable.ic_fingerprint_24px);
  }
  private static List<ChildModel> makecreate_parentalChild() {
    ChildModel queen = new ChildModel(R.string.create_parental_code_text, true);
    return Arrays.asList(queen);
  }

  private static HeadModel makerecord() {
    return new HeadModel(R.string.record_your_voice, makerecordChild(), R.drawable.ic_album_24px);
  }
  private static List<ChildModel> makerecordChild() {
    ChildModel queen = new ChildModel(R.string.record_your_voice_text, true);
    return Arrays.asList(queen);
  }

  private static HeadModel makeinsert_picture() {
    return new HeadModel(R.string.insert_picture, makeinsert_pictureChild(), R.drawable.ic_photo_size_select_actual_24px);
  }
  private static List<ChildModel> makeinsert_pictureChild() {
    ChildModel queen = new ChildModel(R.string.insert_picture_text, true);
    return Arrays.asList(queen);
  }

  private static HeadModel makeyoung_ones() {
    return new HeadModel(R.string.young_ones, makeyoung_onesChild(), R.drawable.ic_face_24px);
  }
  private static List<ChildModel> makeyoung_onesChild() {
    ChildModel queen = new ChildModel(R.string.young_ones_text, true);
    return Arrays.asList(queen);
  }
}

