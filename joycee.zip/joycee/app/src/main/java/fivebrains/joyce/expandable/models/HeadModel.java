package fivebrains.joyce.expandable.models;

import java.util.List;

public class HeadModel extends ExpandableGroup<ChildModel> {

  private int iconResId;

  public HeadModel(int title, List<ChildModel> items, int iconResId) {
    super(title, items);
    this.iconResId = iconResId;
  }

  public int getIconResId() {
    return iconResId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof HeadModel)) return false;

    HeadModel genre = (HeadModel) o;

    return getIconResId() == genre.getIconResId();

  }

  @Override
  public int hashCode() {
    return getIconResId();
  }
}

