package fivebrains.joyce.fragment;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.R;
import fivebrains.joyce.TextFileReaderActivity;
import fivebrains.joyce.customview.CustomTextView;
import fivebrains.joyce.db.DatabaseHandler;
import fivebrains.joyce.db.Language;

public class PageFragment extends Fragment {

    private String imageResource;
    // private Bitmap bitmap;
    @BindView(R.id.name)
    CustomTextView name;
    @BindView(R.id.lang_name)
    CustomTextView lang_name;
    @BindView(R.id.image)
    ImageView image;

    /*=================================================*/
    @BindView(R.id.lllang)
    CustomTextView lllang;
    @BindView(R.id.llname)
    CustomTextView llname;

    /*=================================================*/

    @BindView(R.id.lname)
    CustomTextView lname;
    @BindView(R.id.limage)
    ImageView limage;

    @BindView(R.id.li)
    LinearLayout mLi;
    @BindView(R.id.li1)
    LinearLayout mLi1;
    @BindView(R.id.parent_li)
    LinearLayout parent_li;
    private MediaPlayer mediaPlayer;
    public static PageFragment getInstance(String resourceID) {
        PageFragment f = new PageFragment();
        Bundle args = new Bundle();
        args.putString("image_source", resourceID);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_page, container, false);
        ButterKnife.bind(this, rootview);

        imageResource = getArguments().getString("image_source");

        System.out.println("======imageResource======" + imageResource);

        final String[] values = imageResource.split("\\*");
        // String name = Directory.getFileNameWithoutExtension(imageResource).toUpperCase();

        final List<Language> lang = DatabaseHandler.getRecord(getActivity(), values[0]);
        parent_li.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  if (null == lang || lang.isEmpty()) {

                }*/
                if(lang!=null&& !lang.isEmpty()) {
                    String path = lang.get(0).getAudioPath();
                    System.out.println("======AudioSavePathInDevice==data base=====" + path);
                   /// System.out.println("======AudioSavePathInDevice==data base=====" + lang.get(0).getName());

                    if (path != null) {
                        mediaPlayer = new MediaPlayer();
                        try {
                            mediaPlayer.setDataSource(path);
                            mediaPlayer.prepare();
                            // showMessage(values[0]);
                        } catch (IOException e) {
                            e.printStackTrace();

                        }

                        mediaPlayer.start();
                        //Toast.makeText(c, "Recording Playing", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


        if (null == lang || lang.isEmpty()) {
            // mImageView.setVisibility(View.GONE);
            llname.setVisibility(View.VISIBLE);
            lllang.setVisibility(View.VISIBLE);
            mLi1.setVisibility(View.GONE);
            llname.setText(values[0]);
            try {
                //lllang.setText(TextFileReaderActivity.langName + " : " + values[1]);
                lllang.setText(values[1]);


            } catch (ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
                lllang.setText("");
            }

        } else {

            try {
                if(lang.get(0).getImagePath().equals("")){
                    llname.setVisibility(View.VISIBLE);
                    lllang.setVisibility(View.VISIBLE);
                    mLi1.setVisibility(View.GONE);
                    llname.setText(values[0]);
                    try {
                        //lllang.setText(TextFileReaderActivity.langName + " : " + values[1]);
                        lllang.setText(values[1]);


                    } catch (ArrayIndexOutOfBoundsException e) {
                        e.printStackTrace();
                        lllang.setText("");
                    }
                }
                else{
                    if (values.length > 1 && values[1] != null) {
                        // do something
                        mLi.setVisibility(View.VISIBLE);
                        mLi1.setVisibility(View.GONE);

                        name.setText(values[0]);
                        lang_name.setText(values[1]);
                        image.setImageURI(Uri.parse(lang.get(0).getImagePath()));


                    } else {
                        llname.setVisibility(View.GONE);
                        lllang.setVisibility(View.GONE);
                        mLi1.setVisibility(View.VISIBLE);
                        mLi.setVisibility(View.GONE);

                        lname.setText(values[0]);
                        limage.setImageURI(Uri.parse(lang.get(0).getImagePath()));

                    }
                }


            } catch (Exception e) {
                e.printStackTrace();

                llname.setVisibility(View.VISIBLE);
                lllang.setVisibility(View.VISIBLE);
                mLi1.setVisibility(View.GONE);
                llname.setText(values[0]);
                try {
                    //lllang.setText(TextFileReaderActivity.langName + " : " + values[1]);
                    lllang.setText(values[1]);


                } catch (ArrayIndexOutOfBoundsException e1) {
                    e1.printStackTrace();
                    lllang.setText("");
                }

                //mImageview.setImageResource(R.mipmap.ic_gallary);
            }
        }


        return rootview;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       /* ImageView imageView = (ImageView) view.findViewById(R.id.image);

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = 4;
        o.inDither = false;
        bitmap = BitmapFactory.decodeResource(getResources(), imageResource, o);
        imageView.setImageBitmap(bitmap);*/
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //bitmap.recycle();
        //bitmap = null;
    }
}
