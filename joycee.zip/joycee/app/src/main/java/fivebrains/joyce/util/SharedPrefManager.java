package fivebrains.joyce.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SharedPrefManager {

    public static final String PREFS_NAME = "Joyce";


    public SharedPrefManager() {
        super();
    }


    public void setParentalCode(Context context, String code) {
        SharedPreferences sharedPref;
        Editor editor;

        sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = sharedPref.edit();
        editor.putString("perental_code", code);
        //editor.commit();
        editor.apply();
    }


    public String getParentalCode(Context context) {
        SharedPreferences sharedPref;
        String text;

        sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        text = sharedPref.getString("perental_code", null);
        return text;
    }


}