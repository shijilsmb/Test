package fivebrains.joyce;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.adapter.FileAdapter;
import fivebrains.joyce.interfaces.RecyclerItemClickListener;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;
import fivebrains.joyce.util.FileOpen;

public class FileActivity extends AppCompatActivity {
    public String root;
    @BindView(R.id.m_recycle_view)
    RecyclerView mRecyclerview;
    FileAdapter languageAdapter;
    ArrayList<Language> list;
    //@BindView(R.id.toolbar)
    // Toolbar mToolbar;
    String home_tag;
    @BindView(R.id.img)
    ImageView mImg;
    @BindView(R.id.back)
    ImageView mBack;
    @BindView(R.id.title_name)
    TextView mName;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    public static String getFileExt(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_file);
        ButterKnife.bind(this);


        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        builder.detectFileUriExposure();

        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("English");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        Resources res = getResources();
        final int newColor = res.getColor(R.color.gray);
        mBack.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        Glide.with(this).load(R.drawable.ic_flying_mogli).into(new GlideDrawableImageViewTarget(mImg));

        Intent intent = getIntent();
        String tag = intent.getStringExtra("title");
        home_tag = intent.getStringExtra("tag");
        final String name = intent.getStringExtra("name");
        mName.setText(name);
        System.out.println("=======name===" + name);
        // list = Directory.readTextFile(FileActivity.this, name);
        System.out.println("======A=list===" + list);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(FileActivity.this);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setItemAnimator(new DefaultItemAnimator());
        root = Environment.getExternalStorageDirectory().toString() + "/" + Directory.FOLDER + "/" + name;

        getFile(root);
        // languageAdapter = new FileAdapter(FileActivity.this, list, mRecyclerview);
        //   mRecyclerview.setAdapter(languageAdapter);
        mRecyclerview.addOnItemTouchListener(
                new RecyclerItemClickListener(FileActivity.this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {

                        //   try{
                        Log.d("path", list.get(position).path);

                        // System.out.println("====path====="+list.get(position).path);
                        File file = new File(list.get(position).path);
                        if (file.isDirectory()) {
                            if (file.canRead() && file.isDirectory()) {
                                getFile(list.get(position).path);
                            }

                        } else {

                            String extension = getFileExt(list.get(position).path);
                            Log.d("extension", extension);

                            if (extension.equalsIgnoreCase("txt")) {

                                System.out.println("====path==name==="+list.get(position).name);
                                if ( list.get(position).name.toLowerCase().indexOf("_videolink.txt".toLowerCase()) != -1 ) {
                                  //  if (list.get(position).name.equalsIgnoreCase("video_links.txt")) {
                                    Intent i = new Intent(FileActivity.this, YoutubeActivity.class);
                                    i.putExtra("path", list.get(position).path);
                                    startActivity(i);
                                } else {
                                    if (home_tag.equals("0")) {
                                        Intent i = new Intent(FileActivity.this, TextFileReaderActivity.class);
                                        i.putExtra("name", list.get(position).name);
                                        i.putExtra("path", list.get(position).path);
                                        i.putExtra("langName", name);

                                        startActivity(i);
                                    } else {
                                        Intent i = new Intent(FileActivity.this, ParentReaderActivity.class);
                                        i.putExtra("name", list.get(position).name);
                                        i.putExtra("path", list.get(position).path);
                                        i.putExtra("langName", name);
                                        startActivity(i);

                                    }
                                }


                            } else {
                                File myFile = new File(list.get(position).path);
                                try {
                                    FileOpen.openFile(FileActivity.this, myFile);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }

                        }
                        // }
                        // catch(IndexOutOfBoundsException e){
                        //     e.printStackTrace();
                        // }

                    }

                })
        );
    }

    private void getFile(String patsh) {
        System.out.println("=======patsh==" + patsh);
        File fpath = new File(patsh);


        list = new ArrayList<Language>();

        File[] files = fpath.listFiles();


/*
        if(!patsh.equals(root)) {
            list.add(new Language(root, root));
            //item.add(root);
            //path.add(root);
            list.add(new Language("../", fpath.getParent()));
            // item.add("../");
            //path.add(f.getParent());
        }
*/


        //fileList.clear();
        for (File file : files) {

            if (!file.isHidden() && file.canRead()) {

                if (file.isDirectory()) {
                    // item.add(file.getName() + "/");
                    list.add(new Language(file.getName(), file.getPath()));
                } else {
                    list.add(new Language(file.getName(), file.getPath()));
                }
                System.out.println("=======Name==" + file.getName());
            }
        }

        languageAdapter = new FileAdapter(FileActivity.this, list, mRecyclerview);
        mRecyclerview.setAdapter(languageAdapter);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
