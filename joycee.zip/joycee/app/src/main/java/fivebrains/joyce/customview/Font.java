package fivebrains.joyce.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.ref.SoftReference;
import java.util.Hashtable;

/**
 * Created by Sunil on 2/10/2016.
 */
public class Font {

    private static final Hashtable<String, SoftReference<Typeface>> fontCache = new Hashtable<String, SoftReference<Typeface>>();

    /**
     * Method to set the font of a text
     *
     * @param view
     * @param context
     * @param attributeSet
     * @param attrs
     * @param fontId
     */
    public static void setCustomFont(View view, Context context, AttributeSet attributeSet, int[] attrs, int fontId) {
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, attrs);
        String customFont = typedArray.getString(fontId);
        setCustomFont(view, context, customFont);
        typedArray.recycle();
    }

    /**
     * @param view
     * @param context
     * @param asset
     * @return
     */
    public static boolean setCustomFont(View view, Context context, String asset) {
        if (TextUtils.isEmpty(asset))
            return false;
        try {
            Typeface typeface = getFont(context, asset);
            if (view instanceof TextView) {
                ((TextView) view).setTypeface(typeface);
            } else if (view instanceof EditText) {
                ((EditText) view).setTypeface(typeface);
            } else if (view instanceof Button) {
                ((Button) view).setTypeface(typeface);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static Typeface getFont(Context context, String fontName) {
        synchronized (fontCache) {
            if (fontCache.get(fontName) != null) {
                SoftReference<Typeface> typefaceSoftReference = fontCache.get(fontName);
                if (typefaceSoftReference.get() != null) {
                    return typefaceSoftReference.get();
                }
            }
            Typeface typeface = Typeface.createFromAsset(context.getAssets(), "fonts/" + fontName);
            fontCache.put(fontName, new SoftReference<Typeface>(typeface));
            return typeface;
        }
    }
}
