package fivebrains.joyce.adapter;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.List;

import fivebrains.joyce.R;
import fivebrains.joyce.expandable.ExpandableRecyclerViewAdapter;
import fivebrains.joyce.expandable.models.ChildModel;
import fivebrains.joyce.expandable.models.ExpandableGroup;
import fivebrains.joyce.expandable.models.HeadModel;
import fivebrains.joyce.expandable.viewholders.ChildViewHolder;
import fivebrains.joyce.expandable.viewholders.GroupViewHolder;

import static android.view.animation.Animation.RELATIVE_TO_SELF;

public class HelpAdapter extends ExpandableRecyclerViewAdapter<HelpAdapter.MyViewHolder, HelpAdapter.MyChildViewHolder> {

  public HelpAdapter(Resources res, List<? extends ExpandableGroup> groups) {
    super(groups);
    resources = res;
  }

  Resources resources;

  public void setResources(Resources resources) {
    this.resources = resources;
  }

  @Override
  public MyViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.list_item_head, parent, false);
    return new MyViewHolder(resources,view);
  }

  @Override
  public MyChildViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.list_item_child, parent, false);
    return new MyChildViewHolder(view);
  }

  @Override
  public void onBindChildViewHolder(MyChildViewHolder holder, int flatPosition,
      ExpandableGroup group, int childIndex) {

    final ChildModel artist = ((HeadModel) group).getItems().get(childIndex);
    holder.setArtistName(resources.getString(artist.getName()));
  }

  @Override
  public void onBindGroupViewHolder(MyViewHolder holder, int flatPosition,
      ExpandableGroup group) {

    holder.setGenreTitle(group);
  }


  public class MyChildViewHolder extends ChildViewHolder {

    private TextView childTextView;

    public MyChildViewHolder(View itemView) {
      super(itemView);
      childTextView = (TextView) itemView.findViewById(R.id.list_item_artist_name);
    }

    public void setArtistName(String name) {
      childTextView.setText(name);
    }
  }


  public class MyViewHolder extends GroupViewHolder {

    private TextView genreName;
    private ImageView arrow;
    private ImageView icon;

    public MyViewHolder(Resources resources,View itemView) {
      super(itemView);
      genreName = (TextView) itemView.findViewById(R.id.list_item_genre_name);
      arrow = (ImageView) itemView.findViewById(R.id.list_item_genre_arrow);
      icon = (ImageView) itemView.findViewById(R.id.list_item_genre_icon);
      arrow.setOnClickListener(this);
    }

    public void setGenreTitle(ExpandableGroup genre) {
      if (genre instanceof HeadModel) {
        genreName.setText(resources.getString(genre.getTitle()));
        icon.setImageResource(((HeadModel) genre).getIconResId());
      }
    /*if (genre instanceof MultiCheckGenre) {
      genreName.setText(genre.getTitle());
      icon.setBackgroundResource(((MultiCheckGenre) genre).getIconResId());
    }
    if (genre instanceof SingleCheckGenre) {
      genreName.setText(genre.getTitle());
      icon.setBackgroundResource(((SingleCheckGenre) genre).getIconResId());
    }*/
    }

    @Override
    public void onClick(View v) {
      if (listener != null) {
        listener.onGroupClick(getAdapterPosition());
      }
    }

    @Override
    public void expand() {
      animateExpand();
    }

    @Override
    public void collapse() {
      animateCollapse();
    }

    private void animateExpand() {
      RotateAnimation rotate =
              new RotateAnimation(360, 180, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
      rotate.setDuration(300);
      rotate.setFillAfter(true);
      arrow.setAnimation(rotate);
    }

    private void animateCollapse() {
      RotateAnimation rotate =
              new RotateAnimation(180, 360, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
      rotate.setDuration(300);
      rotate.setFillAfter(true);
      arrow.setAnimation(rotate);
    }
  }

}
