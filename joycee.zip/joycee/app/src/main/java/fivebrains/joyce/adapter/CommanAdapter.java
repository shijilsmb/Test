package fivebrains.joyce.adapter;

/**
 * Created by Created by Sunil on 11-10-2016.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.R;
import fivebrains.joyce.ViewPagerActivity;
import fivebrains.joyce.customview.CustomTextView;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;


public class CommanAdapter extends RecyclerView.Adapter {
    private List<Language> itemsList;
    private Context mContext;
    public static final int VIEW_ITEM = 1;
    public static final int VIEW_PROG = 0;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    RecyclerView recyclerView;

    public CommanAdapter(Context context, List<Language> recomendedArrayList, RecyclerView mrecyclerView) {
        this.itemsList = recomendedArrayList;
        this.mContext = context;
        recyclerView = mrecyclerView;


    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.text_file, parent, false);

            return new CommanAdapter.SingleItemRowHolder(v);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {


        if (holder instanceof CommanAdapter.SingleItemRowHolder) {
            //  Merchants merchants = itemsList.get(position);
            Language language = itemsList.get(position);

             String [] values=language.name.split("\\*");
            ((SingleItemRowHolder) holder).mLanguage.setText(values[0]);
            ((SingleItemRowHolder) holder).mArrow.setTag(position);
            ((SingleItemRowHolder) holder).mArrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos= (int) view.getTag();
                    Intent intent=new Intent(mContext, ViewPagerActivity.class);
                    intent.putParcelableArrayListExtra("list", (ArrayList<? extends Parcelable>) itemsList);
                    intent.putExtra("position", pos);
                    mContext.startActivity(intent);
                    //Toast.makeText(mContext,"Hello",Toast.LENGTH_SHORT).show();
                }
            });

        }

    }

    @Override
    public int getItemCount() {
        return itemsList == null ? 0 : itemsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return itemsList.get(position) == null ? VIEW_PROG : VIEW_ITEM;
    }

    public class SingleItemRowHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.language)
        protected CustomTextView mLanguage;

        @BindView(R.id.img_arrow)
        protected ImageView mArrow;

        public SingleItemRowHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);

        }

    }


}