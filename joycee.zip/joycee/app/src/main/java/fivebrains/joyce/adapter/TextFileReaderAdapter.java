package fivebrains.joyce.adapter;

/**
 * Created by Created by Sunil on 11-10-2016.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fivebrains.joyce.R;
import fivebrains.joyce.models.Language;
import fivebrains.joyce.util.Directory;


public class TextFileReaderAdapter extends RecyclerView.Adapter {
    private List<Language> itemsList;
    private Context mContext;
    public static final int VIEW_ITEM = 1;
    public static final int VIEW_PROG = 0;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    RecyclerView recyclerView;

    public TextFileReaderAdapter(Context context, List<Language> recomendedArrayList, RecyclerView mrecyclerView) {
        this.itemsList = recomendedArrayList;
        this.mContext = context;
        recyclerView = mrecyclerView;


    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.row_file, parent, false);

            return new TextFileReaderAdapter.SingleItemRowHolder(v);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {


        if (holder instanceof TextFileReaderAdapter.SingleItemRowHolder) {
            //  Merchants merchants = itemsList.get(position);
            Language language = itemsList.get(position);

            ((SingleItemRowHolder) holder).mLanguage.setText(Directory.getFileNameWithoutExtension(language.name).toUpperCase());
        }

    }

    @Override
    public int getItemCount() {
        return itemsList == null ? 0 : itemsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return itemsList.get(position) == null ? VIEW_PROG : VIEW_ITEM;
    }

    public class SingleItemRowHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.language)
        protected TextView mLanguage;

        public SingleItemRowHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);

        }

    }


}